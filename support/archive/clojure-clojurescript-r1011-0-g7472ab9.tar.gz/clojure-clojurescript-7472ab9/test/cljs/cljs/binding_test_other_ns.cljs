(ns cljs.binding-test-other-ns)

(def *foo* 1)