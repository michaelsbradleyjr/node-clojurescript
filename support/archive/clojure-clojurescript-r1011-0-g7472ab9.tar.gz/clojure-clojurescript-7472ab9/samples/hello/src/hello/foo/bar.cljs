(ns hello.foo.bar)

(defn sum [xs]
  (reduce + 0 xs))
